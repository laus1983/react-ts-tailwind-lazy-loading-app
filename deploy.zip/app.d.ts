type IFoxImageInfo = { id: string; url: string };
